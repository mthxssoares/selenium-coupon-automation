# language: pt

Funcionalidade: Receber o cupom desconto da QAzando
  Eu como usuário da QAzando
  Quero receber um cupom de desconto
  Para comprar um curso com valor reduzido

  @gerar-cupom
  Cenário: Visualizar código de desconto
    Dado que acesso o site da QAzando
    Quando eu preencho meu e-mail
    E clico em ganhar cupom
    Então eu vejo o código de desconto