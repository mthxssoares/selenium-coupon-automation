package support;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import runner.RunCucumberTeste;
import java.time.Duration;

public class Utils extends RunCucumberTeste {

    public void esperarElementoEstarPresente(By element, int tempo){
        WebDriverWait wait=  new WebDriverWait(driver, Duration.ofSeconds(tempo));;
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }
}
