package steps;


import io.cucumber.java.es.Dado;
import io.cucumber.java.it.Quando;
import io.cucumber.java.pt.Então;
import org.junit.Assert;
import org.openqa.selenium.By;
import pages.HomePage;
import runner.RunCucumberTeste;

public class DescontosStep extends RunCucumberTeste {

        HomePage homePage = new HomePage(driver);

        @Dado("que acesso o site da QAzando")
        public void que_acesso_o_site_da_qazando() {
                homePage.acessarAplicaçao();

        }

        @Quando("eu preencho meu e-mail")
        public void eu_preencho_meu_email() throws InterruptedException {
                homePage.preencherEmail();

        }

        @Quando("clico em ganhar cupom")
        public void clico_em_ganhar_cupom() {
                homePage.cliqueGanhardesconto();
        }

        @Então("eu vejo o código de desconto")
        public void eu_vejo_o_codigo_de_desconto() {
                homePage.validarCodigoDesconto();
        }
}