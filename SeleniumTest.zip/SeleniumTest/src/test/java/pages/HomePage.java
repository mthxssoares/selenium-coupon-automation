package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import support.Utils;

public class HomePage extends Utils {

    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void acessarAplicaçao() {
        driver.get("https://qazando.com.br/curso.html");

        Assert.assertEquals(
                "Não foi possível acessar a aplicação!",
                true,
                driver.findElement(By.id("btn-ver-cursos")).isDisplayed()
        );
    }

    public void preencherEmail() throws InterruptedException {
        Thread.sleep(2000);

        WebElement campoEmail = driver.findElement(By.id("email"));

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block: 'center'});",
                campoEmail
        );

        Thread.sleep(1000);

        campoEmail.sendKeys("finotti@qazando.com.br");
    }

    public void cliqueGanhardesconto(){
        driver.findElement(By.id("button")).click();
    }

    public void validarCodigoDesconto(){
        String texto_cupom = driver.findElement(By.cssSelector("#cupom > h2 > span")).getText();

        Assert.assertEquals("O CUPOM ESTA ERRADO", "QAZANDO15OFF", texto_cupom);

        System.out.println("Teste finalizado com sucesso!");
    }
}